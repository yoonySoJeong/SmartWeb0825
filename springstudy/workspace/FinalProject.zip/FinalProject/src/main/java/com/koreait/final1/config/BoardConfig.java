package com.koreait.final1.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class BoardConfig {

	
	
}
